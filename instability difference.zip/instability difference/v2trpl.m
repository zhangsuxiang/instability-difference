	function [trpl]=v2trpl(xyz)
%	Transforms from XYZ components of a unit vector to
%	  the trend and plunge for the vector.
%	Trend is the azimuth (clockwise from north looking down)
%	Plunge is the downward dip measured from the horizontal.
%	All angles in degree
%	X is north, Y is east, Z is down
%	If the component of Z is negative (up), the plunge,TRPL(2),
%	  is replaced by its negative and the trend, TRPL(1),
%	  Is changed by PI.
%	The trend is returned between 0 and 2*PI, the plunge
%	  between 0 and PI/2.
%	12 January 2000: If xyz(3) = -1.0, make the trend PI.  Made
%	  consistency in the roundoff -- all are now 0.0001
%-
for j=1:3
 if (abs(xyz(j))<= 0.0001)
      xyz(j) = 0.0;
 end
 if (abs(abs(xyz(j))-1.0)<0.0001)
    xyz(j)=xyz(j)/abs(xyz(j));
 end
end
if (abs(xyz(3))==1.0) 
%	plunge is 90 degrees
  if (xyz(3)< 0.0)
    trpl(1) = pi;
  else
    trpl(1) = 0.0;
  end 
  trpl(2) = 0.5*pi;
  return
  end
if (abs(xyz(1))< 0.0001)
  if (xyz(2)> 0.0)
    trpl(1) = pi/2;
  elseif(xyz(2)< 0.0)
    trpl(1) = 3.0*pi/2.0;
  else
    trpl(1) = 0.0;
  end
else
  trpl(1) = atan2(xyz(2),xyz(1));
end
C = cos(trpl(1));
S = sin(trpl(1));
if (abs(C)>= 0.1) trpl(2) = atan2(xyz(3),xyz(1)/C);  end
if (abs(C)<0.1) trpl(2) = atan2(xyz(3),xyz(2)/S);end 
if (trpl(2)<0.0) 
  trpl(2) = -trpl(2);
  trpl(1) = trpl(1) - pi;
 end
if (trpl(1)< 0.0) trpl(1) = trpl(1) + 2.0*pi;end
   trpl=rad2deg(trpl);
return
